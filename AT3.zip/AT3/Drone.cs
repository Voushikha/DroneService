﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AT3
{
    public class Drone
    {
        public void GetClientName()
        {
            throw new System.NotImplementedException();
        }

        public void SetClientName()
        {
            throw new System.NotImplementedException();
        }

        public void GetDroneMode()
        {
            throw new System.NotImplementedException();
        }

        public void SetDroneModel()
        {
            throw new System.NotImplementedException();
        }

        public void GetServiceProblem()
        {
            throw new System.NotImplementedException();
        }

        public void SetServiceProblem()
        {
            throw new System.NotImplementedException();
        }

        public void GetServiceCost()
        {
            throw new System.NotImplementedException();
        }

        public void SetServiceCost()
        {
            throw new System.NotImplementedException();
        }

        public void GetServiceTag()
        {
            throw new System.NotImplementedException();
        }

        public void SetServiceTag()
        {
            throw new System.NotImplementedException();
        }

        public void DisplayDetails()
        {
            throw new System.NotImplementedException();
        }
    }
}